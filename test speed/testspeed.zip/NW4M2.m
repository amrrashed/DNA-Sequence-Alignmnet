clc;clear;
%elapsed time comparison for global alignment needleman-wunsh algorithm
% load matrix2.mat d seq1 seq2 b
load matrix4.mat alig %LUT for NW algorithm
load('indexx.mat')
load('D:\PHD DNA REF\DNA SEQUENCE CODES\ALL MAT files\matrix5.mat')
%load('D:\PHD DNA REF\DNA SEQUENCE CODES\ALL MAT files\index.mat')
[Header, seq1] = fastaread("NC_000913.3.fasta");
[Header2, seq2] = fastaread("NC_000962.3.fasta");
% seq1=gpuArray(seq1);
%[score1, alignment1] = swalign(seq1(i,:),seq2(i,:),'GapOpen',5);
T1='0';
querylength=4000;
seq11=reshape(seq1(1:querylength),4,querylength/4);
seq22=reshape(seq2(1:querylength),4,querylength/4);
seqcom=[seq11',seq22'];
in=zeros(querylength,16);
out=repmat(T1,querylength,18);
o1=zeros(querylength,1);
tic
for i=1:length(seqcom)
in(i,:)=tr2(seqcom(i,:));
seq(i)=bin2dec(tr2(seqcom(i,:)));
%b starts from 0 in location 1
out(i,:)=alig(seq(i)+1,:);
o1(i)=z(seq(i)+1);
end
Elapsed_time=toc
GCUPS=(querylength)^2/(Elapsed_time*1e9)
in2=floor(in/49);
label={'''fr1','''fr2','''fr3','''fr4','''fr5','''fr6','''fr7','''fr8','''fr9','''fr10','''fr11','''fr12','''fr13','''fr14','''fr15','''fr16','''class'};
A=[in2,o1];
csvwrite('phdtest4000.csv',label,0,0)
csvwrite('phdtest4000.csv',A,1,0)