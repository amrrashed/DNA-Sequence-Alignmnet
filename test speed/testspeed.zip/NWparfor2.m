clc;clear;
%elapsed time comparison for global alignment needleman-wunsh algorithm
%6-core 
% load matrix2.mat d seq1 seq2 b
load matrix4.mat alig
[Header, seq1] = fastaread("NC_000913.3.fasta");
[Header2, seq2] = fastaread("NC_000962.3.fasta");
% seq1=gpuArray(seq1);
querylength=4400000;
seq11=reshape(seq1(1:querylength),4,querylength/4);
seq22=reshape(seq2(1:querylength),4,querylength/4);
seqcom=[seq11',seq22'];
tic
parfor i=1:length(seqcom)
seq(i)=bin2dec(tr2(seqcom(i,:)));
%b starts from 0 in location 1
out(i,:)=alig(seq(i)+1,:);
end
Elapsed_time=toc
GCUPS=(querylength)^2/(Elapsed_time*1e9)
