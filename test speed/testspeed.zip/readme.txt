NC_000962.3 represents the Mycobacterium tuberculosis H37Rv genome of length 4,411,532 nucleotides.
NC_000913.3 represents the Escherichia coli K12 MG1655 genome of length 4,641,652 nucleotides.
