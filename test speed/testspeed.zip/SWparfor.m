clc;clear;
%elapsed time comparison for global alignment needleman-wunsh algorithm
% load matrix2.mat d seq1 seq2 b
load matrix3.mat alig
[Header, seq1] = fastaread("C:\Users\amr_r\OneDrive\Desktop\ieee paper\software\NC_000913.3.fasta");
[Header2, seq2] = fastaread("C:\Users\amr_r\OneDrive\Desktop\ieee paper\software\NC_000962.3.fasta");
% seq1=gpuArray(seq1);
querylength=4400000;
seq1=reshape(seq1(1:querylength),querylength/4,4);
seq2=reshape(seq2(1:querylength),querylength/4,4);
tic
parfor i=1:length(seq1)
seq(i)=bin2dec(tr2([seq1(i,:),seq2(i,:)]));
%b starts from 0 in location 1
out(i,:)=alig(seq(i)+1,:);
end
Elapsed_time=toc
GCUPS=(querylength)^2/(Elapsed_time*1e9)
