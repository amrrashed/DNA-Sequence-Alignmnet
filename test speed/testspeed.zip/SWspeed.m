clc;clear;
%elapsed time comparison for local alignment smith-waterman algorithm
load matrix2.mat d seq1 seq2 b
load matrix3.mat alig
T1='0';
out=repmat(T1,length(d),12);
parfor i=1:length(alig)
tStart=tic;
seq(i)=bin2dec(tr2([seq1(i,:),seq2(i,:)]));
%b starts from 0 in location 1
out=alig(seq(i)+1,:);
tElapsed(i) = toc(tStart);
end
mean1=mean(tElapsed);
min2=min(tElapsed) ;
max3=max(tElapsed) ;
s=std(tElapsed); 
var4=var(tElapsed);
GCUPS=(4)^2/(mean1*1e9)
disp(['mean=' ,num2str(mean1),'  min=' ,num2str(min2),'  max=' ,num2str(max3),'  std=' ,num2str(s),'  var=' ,num2str(var4)])
%s4=std(tElapsed)
% figure
% histogram(tElapsed,10)
 GCUPS=(4)^2/(mean1*1e9)
 


