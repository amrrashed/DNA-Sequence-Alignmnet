clc;clear;
%elapsed time comparison for global alignment needleman-wunsh algorithm
% load matrix2.mat d seq1 seq2 b
load matrix4.mat alig %LUT for NW algorithm
load('D:\PHD DNA REF\DNA SEQUENCE CODES\ALL MAT files\index.mat')
[Header, seq1] = fastaread("NC_000913.3.fasta");
[Header2, seq2] = fastaread("NC_000962.3.fasta");
% seq1=gpuArray(seq1);
%[score1, alignment1] = swalign(seq1(i,:),seq2(i,:),'GapOpen',5);
T1='0';
queryl=4400;
in=zeros(queryl,16);
out=repmat(T1,queryl,18);
o1=zeros(queryl,1);
tic
k=1;
for i=1:queryl
in(i,:)=tr2([seq1(i:i+3),seq2(i:i+3)]);
seq(i)=bin2dec(tr2([seq1(i:i+3),seq2(i:i+3)]));
%b starts from 0 in location 1
out(k,:)=alig(seq(k)+1,:);
o1(k)=z(seq(k)+1);
k=k+1;
end
Elapsed_time=toc
GCUPS=(queryl)^2/(Elapsed_time*1e9)
 in2=floor(in/49);
A=[in2,o1];
csvwrite('phdtest4400.csv',A)