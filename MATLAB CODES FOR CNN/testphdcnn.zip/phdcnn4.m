clc;clear;%delete(findall(0))
%remove class which have less than 10 image
%18 class are removed
%remaining 236 class
%acc=94.16%
%phdcnn.m
digitDatasetPath = fullfile('D:\PHD DNA REF\DNA PHD MATLAB CODES\matlab codes 2019\phdcnn3');
imds = imageDatastore(digitDatasetPath, ...
    'IncludeSubfolders',true,'LabelSource','foldernames');
%use opengl instead of using graphic card because it crashs
%opengl('save', 'software')
%deepNetworkDesigner
%remove class which have less than 10 image
%labelCount = countEachLabel(imds);
% x=tabulate(z);
% k=find(x(:,2)<10);
% for h=1:length(k)
% %removes DIRECTORY, including the subdirectory 
% %tree and all files, from the parent directory  
% rmdir(strcat([filename num2str(k(h))]),'s') 
% end
imds = imageDatastore(digitDatasetPath, ...
    'IncludeSubfolders',true,'LabelSource','foldernames');
img = readimage(imds,1);
size(img)
[imdsTrain,imdstest] = splitEachLabel(imds,0.8,'randomized');
numClasses = numel(categories(imdsTrain.Labels));
%MODEL 1
% layers = [
%     imageInputLayer([4 4 1])
%     
%     convolution2dLayer(5,5,'Padding',3)
%     batchNormalizationLayer
%     reluLayer
%     
%     fullyConnectedLayer(254)
%     softmaxLayer
%     classificationLayer];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MODEL 2
layers = [
    imageInputLayer([8 8 1])
    convolution2dLayer(5,5,'Padding',3)
    batchNormalizationLayer
    reluLayer
    fullyConnectedLayer(500)
    dropoutLayer
    reluLayer
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];
%model 3
% layers = [
%     imageInputLayer([4 4 1])
%     
%     convolution2dLayer(8,8,'Stride',1,'Padding',3)
%     batchNormalizationLayer
%     reluLayer
%     
%     fullyConnectedLayer(254)
%     softmaxLayer
%     classificationLayer];
 options = trainingOptions('sgdm', ...
    'InitialLearnRate',0.01, ...
    'Verbose',false, ...
    'Shuffle','every-epoch', ...
    'Plots','training-progress');
%%,'OutputFcn',@(info)savetrainingplot(info)
%70-30 model1
% 0.9483 sgdm database1       0.8426 sgdm database2     0.8460  sgdm database3   
% 0.8626 rmsprop database1   0.7942 rmsprop database2   0.7876 rmsprop database3
% 0.8962 adam database1     0.8175  adam database2    0.7997 adam database3
%80-20 model1
%  0.9669 sgdm database1        0.8583 sgdm database2     0.8493  sgdm database3   
%   0.8545  rmsprop database1    0.7945 rmsprop database2   0.7809 rmsprop database3
%   0.9040  adam database1     0.8151  adam database2     0.8190 adam database3
%80-20 new layers model2
%  0.9808    sgdm database1      0.9836    sgdm database2    0.9837   sgdm database3   
%   0.8458  rmsprop database1     0.8310 rmsprop database2  0.8402   rmsprop database3
%  0.9172 adam database1      0.8303  adam database2    0.8763  adam database3
%80-20 model3
%   0.9428 sgdm database1       0.9844   sgdm database2      0.9843  sgdm database3   
%    0.8897  rmsprop database1    0.8946 rmsprop database2    0.8895 rmsprop database3
%     0.9173 adam database1      0.9467 adam database2     0.9189 adam database3
net = trainNetwork(imdsTrain,layers,options);
analyzeNetwork(net)
YPred = classify(net,imdstest);
Ytest = imdstest.Labels;
accuracy = sum(YPred == Ytest)/numel(Ytest)
%%save Network
 save simplephd.mat net layers
%% Try to classify something else
img = readimage(imds,3);
actualLabel = imds.Labels(3);
predictedLabel = net.classify(img);
imshow(img);
title(['Predicted: ' char(predictedLabel) ', Actual: ' char(actualLabel)])
 


