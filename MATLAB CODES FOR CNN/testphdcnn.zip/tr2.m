function [ y2 ] = tr2( x )
k=1;
for i=1:length(x)
   z=lower(x(i)); 
    if (strcmp(z,'a'))
           y(k,1:2)='00';
       elseif(strcmp(z,'c'))
           y(k,1:2)='01';
       elseif(strcmp(z,'g'))
          y(k,1:2)='10'; 
       elseif(strcmp(z,'t'))
          y(k,1:2)='11';  
   end      
   k=k+1; 
end
y2=reshape(y',1,length(y)*2);  
end