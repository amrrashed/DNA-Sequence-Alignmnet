clc;clear
%decoding from index to *
load matrix5.mat
load index.mat
c=[alig2,num2str(z')];
d=unique(c(1:end,:),'rows')