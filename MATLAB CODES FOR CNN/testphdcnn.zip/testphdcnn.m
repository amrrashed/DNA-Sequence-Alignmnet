clc;clear
%test pdh cnn network
load  simplephd.mat net layers
load matrix5.mat
load index.mat
[Header, seq1] = fastaread("C:\Users\amr_r\OneDrive\Desktop\ieee paper\software\NC_000913.3.fasta");
[Header2, seq2]= fastaread("C:\Users\amr_r\OneDrive\Desktop\ieee paper\software\NC_000962.3.fasta");
% seq1=gpuArray(seq1);
querylength=200000;
seq1=reshape(seq1(1:querylength),querylength/4,4);
seq2=reshape(seq2(1:querylength),querylength/4,4);
seq=[seq1,seq2];
C=zeros(1,16);
parfor i=1:(querylength/4)
C(i,:)=255.*floor(tr2(seq(i,:))/49);
end
parfor j=1:(querylength/4)
d=repmat(double(reshape(C(j,:),[2 8])),[4 1]);
tic
predictedLabel(j) = classify(net,d,'ExecutionEnvironment','GPU');
T(j)=toc;
end
tMul = sum(T)
% for k=1:length(predictedLabel)
% m=find(z==predictedLabel(k),1);
%  m=find(z==47,1);
%  p=findstr(alig2(m,:),'*');
%  alig2(m,p)=seq(1,:);
%  disp(alig2(m,:))
% end
GCUPS=(querylength)^2/(tMul*1e9)
